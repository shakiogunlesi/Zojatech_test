import React, {useState} from "react";
import ReactCodeInput from 'react-input-verification-code';
import AuthLayout from './authLayout'
import { useNavigate } from "react-router-dom";
import { verifyOtp, resetOtp } from './services/authservice'

function VerifyCode(){

    const navigate = useNavigate()

    const [otp, setOtp] = useState(null)

    const btnIsEnabled = otp && !isNaN(otp) && otp.length === 4

    const verifiedEmail = () => {
        verifyOtp(otp).then(res=>{
            if(res.success){
                navigate('/emailverify')
            }else{
                alert(res.message)
            }
        })
    }
    return (
        <AuthLayout>
            <div className="f_card" style={{ padding: '60px' }}>
                <form className="form-signin">
                <h2 className="form-signin-heading">Verify your email</h2>
                <p className="ftex2">A four digit OTP code has been sent to your email <a href="/">seyi@zojatech.</a></p>
                <div className="col-12"  style={{ marginBottom: '30px' }}>
                    <ReactCodeInput
                        validChars="0-9"
                        inputProps={{type: "tel"}}
                        length={4}
                        onChange={(e)=>setOtp(e)}
                    />
                </div>
                <button 
                    disabled={!btnIsEnabled}
                    style={btnIsEnabled ? {color:'#F6F8F9', backgroundColor:'#FF8600'} : {color:'#C3C7CE', backgroundColor:'#ECEDED'}} 
                    onClick={()=>verifiedEmail()} 
                    type="button" 
                    className="crt-btn2 border-0">Confirm Email</button><br />
                <label className="ftex"><span style={{ paddingRight: '10px' }}>Didn’t get the mail?</span> 
                <span style={{color:'#FF8600', cursor:'pointer'}}  onClick={()=>resetOtp()} className="text-decoration-underline">Resend</span></label>
                </form>
            </div>
        </AuthLayout>
                    
    )
}

export default VerifyCode;
