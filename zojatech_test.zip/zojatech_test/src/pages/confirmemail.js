import React from "react";
import checkMail from './images/check_mail.png';
import AuthLayout from './authLayout'
import { useNavigate } from "react-router-dom";


function  ConfirmEmail () {
    const navigate = useNavigate()
    const verifyCode = () => {
        navigate('/verifycode')
    }
    return (
        <AuthLayout>
            <div className="f_card f_card2">
                <img className="svg" src={checkMail} alt="Check_Mail" width="102" height="42" />
                <form className="form-signin">
                <h2 className="form-signin-heading" style={{ textAlign: 'center' }}>Check your mailbox !</h2>
                <p className="ftex2">We’ve sent an email to seyi@zojatech.com with a an OTP to confirm your account. Check your inbox to  activate your account.</p>
                
                <button onClick={()=>verifyCode()} type="button" className="crt-btn2">Confirm Email</button><br />
                <label className="ftex"><span className="spacsty">Didn’t get the mail?</span> <a href="/">Resend</a></label>
                </form>
            </div>
        </AuthLayout>
                
    )
}

export default ConfirmEmail;