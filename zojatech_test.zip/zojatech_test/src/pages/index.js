import React from 'react';
import {
  BrowserRouter as Router,
  Route,
  Routes
} from "react-router-dom";
import Home from './home';
import Registration from './registration';
import RegisterAuthentication from './registerauthentication';
import ConfirmEmail from './confirmemail';
import VerifyCode from './verifycode';
import EmailVerify from './emailverify';
import Dashboard from './dashboard';
const Pages = () => {
    return(
        <Router>
            <Routes>
                <Route index element={<Home />} />
                <Route path="/registration" element={<Registration />} />
                <Route path="/registerauthentication" element={<RegisterAuthentication />} />
                <Route path="/confirmemail" element={<ConfirmEmail />} />
                <Route path="/verifycode" element={<VerifyCode />} />
                <Route path="/emailverify" element={<EmailVerify />} />
                <Route path="/dashboard" element={<Dashboard />} />
            </Routes>
        </Router>
    );
};
export default Pages;