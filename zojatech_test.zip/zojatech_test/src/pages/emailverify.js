import React from "react";
import checkedEmail from './images/checked-email.png';
import { Button } from 'react-bootstrap';
import { Link } from "react-router-dom";
import AuthLayout from './authLayout'


function EmailVerify() {
    return (
        <AuthLayout>
            <div className="f_card f_card2">
                <img className="svg" src={checkedEmail} alt="Checked_Email" width="60" height="42" />
                <form className="form-signin">
                    <h2 className="form-signin-heading" style={{ textAlign: 'center' }}>Email verified !</h2>
                    <p className="ftex2">The verified email address will be associated with <br />your account. Click on the button below to continue</p>
                    <Link to="/dashboard">
                    <button onClick={()=>Button()} type="button" className="crt-btn2">Continue</button><br />
                    </Link>
                </form>
            </div>
        </AuthLayout>
    )
}


export default EmailVerify;