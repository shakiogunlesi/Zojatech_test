import React, {useState} from 'react';
import { registerService } from './services/authservice';
import validator from 'validator'
import AuthLayout from './authLayout'
import { useNavigate } from "react-router-dom";
import { Alert } from 'bootstrap';



function Registration () {
   
    const navigate = useNavigate();

    const [first_name, setFirstName] = useState(null);
    const [last_name, setLastName] = useState(null);
    const [email, setEmail] = useState(null);
    const [password,setPassword] = useState(null);


  const [isValidEmail, setIsValidEmail] = useState(false)
  const validateEmail = (e) => {
    var email = e.target.value
    if (validator.isEmail(email)) {
      setIsValidEmail(true)
    } else {
      setIsValidEmail(false)
    }
    handleInputChange(e)
  }

  const [showPassword, setShowPassword] = useState(false)

  

  const btnIsEnabled =  (first_name && first_name.length>0) &&  (last_name && last_name.length>0) && isValidEmail &&  (password && password.length > 0)
  

    const handleInputChange = (e) => {
        const {id , value} = e.target;
        if(id === "first_name"){
            setFirstName(value);
        }
        if(id === "last_name"){
            setLastName(value);
        }
        if(id === "email"){
            setEmail(value);
        }
    if(id === "password"){
            setPassword(value);
        }

    }

    const handleSubmit  = () => {
        registerService({
            first_name:first_name,
            last_name:last_name,
            email:email,
            password:password
        }).then(res=>{
            if(res.success){
                navigate('/confirmemail')
            }else{
                Alert(res.message)
            }
        })
    }

    
        return (
            <AuthLayout>
                <div className="f_card">
                                <form className="form-signin">
                                <h2 className="form-signin-heading">Register your account<br />
                                <span className="ftex">Proceed to create account and setup your organization</span>
                                </h2>
                                <div className="row space_bottom">
                                    <div className="col-sm-6">
                                    <label htmlFor="first_name" className="sr-only">First Name</label>
                                    <input type="text" value={first_name} onChange = {(e) => handleInputChange(e)} id="first_name" name="first_name" className="form-control" placeholder="First Name" required autoFocus />
                                    <span className="icon fa fa-user fa-lg"></span>
                                    </div>
                                    <div className="col-sm-6">
                                    <label htmlFor="last_name" className="sr-only"> Last Name</label>
                                    <input type="text" value={last_name} onChange = {(e) => handleInputChange(e)} id="last_name" name="last_name" className="form-control" placeholder="Last Name" required autoFocus />
                                    <span className="icon fa fa-user fa-lg"></span>
                                    </div>
                                </div>
                                <div className="row regsty">
                                    <label htmlFor="email" className="sr-only"> Email address</label>
                                    <input type="email" value={email} onChange = {(e) => validateEmail(e)} id="email" name="email" className="form-control" placeholder=" Work Email" required autoFocus />
                                    <span className="icon fa fa-envelope fa-lg"></span>
                                    {isValidEmail && <span className="icon2 fa fa-check fa-lg fa_checksty"></span>}
                                </div>
                                <div className="row regsty">
                                    <label htmlFor="password" className="sr-only">Password</label>
                                    <input type={showPassword ? 'text' : 'password'} value={password} onChange = {(e) => handleInputChange(e)} id="password" name="password" className="form-control" placeholder=" Password" required autoComplete="on" />
                                    <span className="icon fa fa-lock fa-lg"></span>
                                    {showPassword && <span style={{cursor:'pointer'}} className="icon2 fa fa-eye fa-lg fa_eyesty" onClick={(e)=>setShowPassword(false)}></span>}
                                    {!showPassword && <span style={{cursor:'pointer'}} className="icon2 fa fa-eye-slash fa-lg fa_eyesty" onClick={(e)=>setShowPassword(true)}></span>}
                                </div>
                                <button 
                                    disabled={!btnIsEnabled}
                                    onClick={()=>handleSubmit()} 
                                    style={btnIsEnabled ? {color:'#F6F8F9', backgroundColor:'#FF8600'} : {color:'#C3C7CE', backgroundColor:'#ECEDED'}} 
                                    type="button" className="crt-btn">Create account</button>
                                <label className="ftex">By clicking the button above, you agree to our <a href="/">Terms of Service</a> and <a href="/">Privacy Policy</a>.</label>
                                <label className="ftex"><span className="spacsty">Already have an account?</span> <a href="/">Login</a></label>
                                </form>
                            </div>
            </AuthLayout>
        )

    
}

export default Registration;