import axios from 'axios'



export const registerService = (data) => {
  return axios
    .post('https://fe-test.revvex.io/api/admin/register', data)
    .then(function (res) {
      localStorage.setItem('token', res?.data?.data?.token);
      localStorage.setItem('email', data.email);
      return res.data
    })
    .catch(function (error) {
      return error?.response?.data
    })
}

export const verifyOtp = (otp) => {
  const token = localStorage.getItem('token');
  return axios
    .post('https://fe-test.revvex.io/api/admin/verify-otp', {otp:otp}, {
      headers: {
        'Authorization': `Bearer ${token}` 
      }
    })
    .then(function (res) {
      return res.data
    })
    .catch(function (error) {
      return error?.response?.data
    })
}

export const resetOtp = () => {
  const token = localStorage.getItem('token');
  const email = localStorage.getItem('email');
  return axios
    .post('https://fe-test.revvex.io/api/admin/resend-otp', {email:email}, {
      headers: {
        'Authorization': `Bearer ${token}` 
      }
    })
    .then(function (res) {
      return res.data
    })
    .catch(function (error) {
      return error?.response?.data
    })
}