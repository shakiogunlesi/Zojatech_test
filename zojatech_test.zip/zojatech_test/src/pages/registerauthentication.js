import React from "react";
import { Button } from 'react-bootstrap';
import { Link } from "react-router-dom";
import companyLogo from './images/logo.png';


class RegisterAuthentication extends React.Component {

    render() {
        return (
            <main>
                <div className="container">
                    <div className="row card-sti" style={{ backgroundColor: '#fff' }}>
                        <div className="col-md-6 dcontlt">
                            <img className="svg" src={companyLogo} alt="Logo" width="117" height="38" />
                            <div className="dcont">
                                <div className="featured-box left-icon">
                                    <div className="featured-icon"> 
                                        <i className="fa fa-check-circle f_icon"></i> 
                                    </div>
                                    <div className="featured-content">
                                        <div className="featured-desc">
                                            <p className="ptext">Track real-time overview of company’s financial <br />performance.</p>
                                        </div>
                                    </div>
                                </div>
                                <div className="featured-box left-icon">
                                    <div className="featured-icon"> 
                                        <i className="fa fa-check-circle f_icon"></i> 
                                    </div>
                                    <div className="featured-content">
                                        <div className="featured-desc">
                                        <p className="ptext">Track created projects budget against actual revenue  <br />and expenses.</p>
                                        </div>
                                    </div>
                                </div>
                                <div className="featured-box left-icon">
                                    <div className="featured-icon"> 
                                        <i className="fa fa-check-circle f_icon"></i> 
                                    </div>
                                    <div className="featured-content">
                                        <div className="featured-desc">
                                            <p className="ptext">Highlighted reports on budget deficit and surplus, <br />accounting dimensions, balance sheets and real-time <br />sales margin estimation.</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div className="dcont">
                                <p className="ptext">© 2022 Revvex. All rights reserved</p>
                            </div>
                        </div>
                        <div className="col-md-6 dcontrt">
                            <div className="f_card">
                                <form className="form-signin">
                                    <h2 className="form-signin-heading">Register your account<br />
                                    <span className="ftex">Proceed to create account and setup your organization</span>
                                    </h2>
                                    <div className="row space_bottom">
                                        <div className="col-sm-6">
                                            <label> First Name</label>
                                            <input type="text" id="first_name" name="first_name" className="form-control" placeholder="Seyi" required autofocus />
                                            <span className="icon fa fa-user fa-lg"></span>
                                        </div>
                                        <div className="col-sm-6">
                                            <label> Last Name</label>
                                            <input type="text" id="last_name" name="last_name" className="form-control" placeholder="Ajayi" required autofocus />
                                            <span className="icon fa fa-user fa-lg"></span>
                                        </div>
                                    </div>
                                    <div className="row regsty">
                                        <label> Email address</label>
                                        <input type="email" id="email" name="email" className="form-control" placeholder="seyi@zojatech.com" required autofocus />
                                        <span className="icon fa fa-envelope fa-lg"></span>
                                        <span className="icon2 fa fa-check fa-lg fa_checksty"></span>
                                        
                                    </div>
                                    <div className="row regsty">
                                        <label>Password</label>
                                        <input type="password" id="password" name="password" className="form-control" placeholder="  .............." required />
                                        <span className="icon fa fa-lock fa-lg"></span>
                                        <span className="icon2 fa fa-eye-slash fa-lg fa_eyesty"></span>
                                    </div>
                                    <Link to="/confirmemail" style={{ color: '#5B6871' }}><button onClick={()=>Button()} type="button" className="crt-btn">Create account</button></Link>
                                    <label className="ftex">By clicking the button above, you agree to our <a href="/">Terms of Service</a> and <a href="/">Privacy Policy</a>.</label>
                                    <label className="ftex"><span className="spacsty">Already have an account?</span> <a href="/">Login</a></label>
                                </form>
                            </div>
                        </div>
                    </div>
                    <div className="row">
                        <div id="mybutton">
                            <button className="gethelp"><span className="get_sty">Get Help </span><i className="fa fa-comment"></i></button>
                        </div>
                    </div>
                </div>
                 
            </main>
        )
    }
}

export default RegisterAuthentication;