import React from 'react';
import 'react-quill/dist/quill.snow.css';
import Pages from './pages';
import './App.css';

function App() {
  return (
    <div>
      <Pages />
    </div>
  );
}
export default App;